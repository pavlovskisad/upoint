# point

Landing page for Point, a Ukrainian lifestyle club in Vienna.

Single file, no build, no dependencies.

```
open index.html          # that's it
npx serve .              # if you want a local server
```

Deploys to Vercel as a static site with zero config.

See `CLAUDE.md` for the concept, the growth rules, the code map, and open questions.