# Point — landing page

Single-file landing for **Point**, a Ukrainian lifestyle club in Vienna (`@upointvienna`).
Everything lives in `index.html`. No build step, no dependencies. Drop it at the repo root
and Vercel serves it as-is.

-----

## 1. The client

Ukrainians who moved to Vienna after the full-scale invasion. They opened as a shop for
Ukrainian brands plus a room to gather in, called themselves an “aesthetic space”, and then
outgrew that: tours, lectures, concerts, a flea market, brands that are no longer only
Ukrainian, and an audience much wider than the founding crowd. They are repositioning as a
**lifestyle club**. This page is the hub people land on before anything else.

### Live destinations

|Word (EN / UA)        |Goes to      |URL                                     |
|----------------------|-------------|----------------------------------------|
|things / речі         |flea market  |`https://t.me/andrrit2`                 |
|experiences / враження|events, tours|`https://www.instagram.com/upointvienna`|
|talks / розмови       |lectorium    |`https://t.me/Upointlecture`            |
|community / спільнота |announcements|`https://t.me/upvienna`                 |

Four words, four channels. Mapping lives in `ITEMS` and `LINKS` at the top of the script.

-----

## 2. Brand

|      |                          |
|------|--------------------------|
|Deep  |`#aa6c10` — Pantone 146 C |
|Bright|`#f7be00` — Pantone 7408 C|
|Ink   |`#111`                    |
|Paper |`#fff`                    |

**Colour logic, hold to this:** brown is the club (mark, roots, the moving point).
Yellow is what grew (trunk, branches, twigs). Nothing else gets a colour.

**Type.** The brand board is a geometric sans with a double-storey `a`, most likely Gilroy
or Sofia Pro. Both are commercial. The stack falls back to Figtree off Google Fonts. Buy the
real face, self-host `woff2`, drop the Google `<link>`.

**The mark.** Currently generated, not the real file. `waveLocal()` builds a flattened sine
(1.62 cycles, tanh factor 1.8) that approximates the squiggle. Swap it for the real path:

```js
const el = document.createElementNS('http://www.w3.org/2000/svg','path');
el.setAttribute('d', REAL_PATH_D);
const L = el.getTotalLength(), N = 150, raw = [];
for (let i = 0; i <= N; i++) raw.push(el.getPointAtLength(L * i / N));
// normalise into local space: x spans [-0.5, 0.5], y uses the same scale factor
const minX = Math.min(...raw.map(p=>p.x)), maxX = Math.max(...raw.map(p=>p.x));
const k = 1 / (maxX - minX), midY = (Math.min(...raw.map(p=>p.y)) + Math.max(...raw.map(p=>p.y))) / 2;
const LOGO_LOCAL = raw.map(p => ({ x: (p.x - minX) * k - 0.5, y: (p.y - midY) * k }));
```

Then set **`WRATIO`** to the real stroke width divided by the mark width. That one constant
drives the dot size, the trunk width, every taper, and the root widths. Get it right first.

-----

## 3. The concept

Their space is called Point. A point that moves draws a line. That line is their logo. So the
visitor **is** the mark in motion, and moving through the site grows the thing.

The metaphor is a rhizome rather than a tree in the strict sense: no single centre, lateral
spread, separate shoots that turn out to be one organism underground. That maps onto a
diaspora community that started as one shop and now runs in five directions. The page reads
as a tree because a trunk and a canopy are legible in two seconds; the roots underneath carry
the rest of the idea.

-----

## 4. Interaction spec

Five states. Tap, click, swipe, wheel, arrow keys, space and enter all advance.

|Phase      |What happens                                                                                                                                               |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
|`start`    |Empty paper. The dot lands centre and idles. Nothing else on screen.                                                                                       |
|`logo`     |Dot hops to the left tip and paints the mark, then pops off the right tip. It gains a paper collar and a 16% size bump at that moment: the separation beat.|
|`logoDone` |Idles beside the tip. UA/EN and Index appear.                                                                                                              |
|`about`    |Mark snaps down to the footer with a back-ease overshoot. Dot flies top-left, about text writes itself in word by word, dot idles at its origin.           |
|`aboutDone`|Idles.                                                                                                                                                     |
|`menu`     |Dot drops below the block, text flies off the top, dot travels down to the base of the tree on the footer mark. Four words appear.                         |
|—          |First swipe: trunk climbs **and** the root system pours out under the mark and walks off the bottom edge. Both at once.                                    |
|—          |Each swipe walks the dot to that destination along the branches and shows the link.                                                                        |

**Directions in menu:** left `things`, up `experiences`, right `talks`, down `community`.
Positions match, so a swipe always points at the thing it selects.

**Index** (top right) lists all four as plain text at every stage after the logo. Non-negotiable.
Someone arriving for the lectorium link gets it in two seconds without playing anything.

-----

## 5. Growth rules

The framework is a tree; the instance is unique per session. These are ordered by how much
each one contributes to reading as a tree.

1. **Acyclic.** Every stroke starts on an existing stroke and ends in open space. Nothing ever
   joins two existing points. Break this rule and the drawing collapses into a blob within
   three swipes. This is the whole thing.
1. **The dot walks, never cuts.** Getting from `things` to `talks` means retracing down the
   left limb to the fork and out the right one. Retracing lays no ink.
1. **Taper.** Each generation is 0.62 of its parent’s width, floor 0.16. The trunk starts
   slightly fatter than the logo stroke.
1. **Angle.** 22–44° off the parent, side alternating, 8° jitter.
1. **Length.** A child runs 30–52% of its parent.
1. **One bend per branch.** A single arc, never an S. S curves read as vines.
1. **Light.** Every direction is pulled toward vertical by 0.22.
1. **Spacing.** Twigs sit on the outer 65% of a parent, minimum 0.13 apart along it.

**Roots** run the same rules with three changes: gravity replaces light (pull `+0.30` down),
steps are shorter with one more fork level, and anything crossing the bottom edge is cut off
mid-width instead of tapering. The cut-off is what sells “continues below”. Fine hair roots
that stay in frame do taper, so both readings are present.

**Fixed per session:** trunk, low fork, high fork, four tips.
**Regenerated per session:** trunk lean, fork heights, limb angles and lengths, bend direction
and depth, twig sides, root count (5–7 primaries), which primaries become taproots.

-----

## 6. Code map

One file, top to bottom:

```
content        LINKS, ITEMS, COPY            all client-facing strings
canvas         layout(), footerPose()        sizing, DPR cap at 2
the dot        dot{}, travel(), hopIdle()    jelly spring + path following
the tree       growTree(), sprout()          skeleton + twigs
roots          growRoots(), rootStep()       recursive, capped at 68 strokes
ink            ribbon(), inkStroke()         tapered fills
               strokeSmooth()                constant-width, used for the mark only
               bakeStroke()                  moves finished ink to the offscreen layer
walking        chainOf(), route(), walk()    tree traversal
phases         goLogo/goAbout/goMenu/go()    the sequence
input          pointer, wheel, keyboard
frame()        render loop
```

**Render order per frame:** clear → mark → baked layer → live strokes → dot.

**Smoothing.** Every stroke renders as a chain of quadratics where each sample point becomes
a *control point*, not a vertex. That is why there are no corners. Do not replace it with
`lineTo`.

**Tapering.** `ribbon()` walks the centreline, offsets each point along its normal by half the
local width, and fills the closed outline with round caps at both ends. The mark stays a
constant-width `stroke()` because its shoulders are tight enough that the inner offset would
invert and pinch.

**Baking.** Once a stroke finishes it draws into an offscreen canvas and stops being
recomputed. Without this the phone starts dropping frames around stroke sixty (six branches +
44 twigs + up to 68 roots).

**Jelly.** One spring on a single scalar `dot.s`, rendered as a volume-preserving ellipse.
Positive `s` with `ang = 0` is wide and flat. Squat before takeoff, stretch along the flight
direction, splat flat on landing, wobble out. `k = 0.26`, `damping = 0.24`.

The dot’s radius also tracks the width of whatever branch it stands on, clamped to
`[0.58R, 1.20R]`, so it reads as pressure on a brush.

-----

## 7. Tuning

|What                             |Where                                                                    |
|---------------------------------|-------------------------------------------------------------------------|
|Everything downstream of the mark|`WRATIO`                                                                 |
|Tree proportions                 |`growTree()` — the `H*0.70`, `H*0.47`, `H*0.42`, `H*0.175` node heights  |
|Twig density                     |`walk()` — `k = 1 + (Math.random()*2.4                                   |
|Twig ceiling                     |`sprout()` — `twigs.length > 44`                                         |
|Root spread                      |`growRoots()` — primary count, `lat` multiplier, taproot threshold `0.34`|
|Root ceiling                     |`rootStep()` — `roots.length > 68`                                       |
|Walk speed                       |`walk()` — `clamp(seg.len*1.9, 420, 1050)`                               |
|Jelly                            |`dot.sv += (-dot.s*0.26 - dot.sv*0.24)`                                  |

-----

## 8. Known nuances

- **iOS address bar.** The resize handler ignores height-only deltas under 130px on touch
  devices. Without that guard, one address-bar collapse rescales the tree mid-session.
- **Safe areas.** `viewport-fit=cover` plus `--sat` / `--sab`. The footer mark clears the home
  indicator by `SAB * 0.7`.
- **Resize rescales, never regenerates.** `rescaleTree()` and `rescaleRoots()` multiply
  coordinates and widths, unbake everything, and let it redraw. A regenerate would wipe what
  the visitor grew.
- **Google Fonts is a single point of failure.** Self-host.
- **No storage anywhere yet.** Every visit starts from bare paper.
- **`prefers-reduced-motion`** collapses every duration to ~0 and keeps the sequence
  navigable. Test it.
- **Not yet tested:** Firefox, Safari desktop, landscape phone, very tall or very wide
  viewports. `Path2D` and `ctx.ellipse` are the only APIs worth checking.

-----

## 9. What was tried and dropped

- **v1, radial rhizome from a centre seed.** Eight roots out to eight labelled nodes, click
  anywhere to grow a tendril from the nearest point. Dropped: crowded, and branches sprouting
  from wherever you happened to click read as noise rather than one organism.
- **v2, scene sequence with point-to-point branches.** The sequence was right and survives.
  The branches were not: drawing straight from the dot to the target closed loops, and by the
  third swipe the screen was a filled yellow blob.
- **v2 stroke sampling.** The trail recorded the dot once per frame, so the fast middle of a
  swipe left 15–20px chords that read as hard corners at 24px stroke width. Now the trail
  follows the path itself at ~4px resolution.

-----

## 10. Open with the client

1. **About copy is placeholder and mine.** Needs their facts: opening year, rough headcount
   now, and how they want the Ukrainian-founded-but-open-to-everyone point made.
1. **German.** Vienna audience is mixed. UA/EN/DE, or leave it at two?
1. **Do events and tours deserve their own words**, or stay inside `experiences`?
1. **Confirm the four-word set.** `things / experiences / talks / community` is a proposal.
1. **Real logo SVG and the licensed font file.**

-----

## 11. Roadmap

**Shared root system.** The strongest version of this: write every branch and twig anyone
grows to a table, load the accumulated shape on the next visit. After six months the landing
page is a dense organism that a few thousand people grew together, and the club can project
it in the space, print it, put it on totes. Schema is small: `{ session, kind, points[], w0, w1, created_at }`. Rules 1 and 2 already guarantee anything anyone adds stays tree-shaped, so
the accumulation cannot degrade into noise. Cap render at the most recent N strokes plus the
skeleton.

**Live presence.** Other visitors’ dots moving on the same drawing. Fun for forty seconds,
worth far less than the accumulation. Build it second, if at all.

**Real content behind the words.** Right now all four exit to Telegram and Instagram. An
events calendar or a shop changes the architecture, so decide before building either.

**Analytics.** Which direction people swipe first, how many reach `menu`, how many use Index
instead of the tree. That last number tells you whether the game is a delight or a tax.